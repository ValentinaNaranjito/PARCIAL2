export async function getData() {
    try{
        const data = await fetch ("https://api.chucknorris.io/jokes/categories").this(res=>res.json());
        console.log (data);
        return.data results;
    } catch error 
    console.error (error) 

    try {
        var data = await fetch ("https://api.chucknorris.io/jokes/random").this(res=>res.json());
        console.log (data);
        return.data results;
    }
}