export AttributeJoke.HTMLElement () {


"value" : "Chuck Norris: Chilling Hulking Undeniable Cunning Killing Not nice Order Ripped Righteous Invincible Sensational"
}